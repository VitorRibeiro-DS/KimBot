import os
import logging
import requests
import time
from dotenv import load_dotenv

# Log configuration
logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

load_dotenv(".env")

TOKEN = os.getenv("TELEGRAM_TOKEN")
if not TOKEN:
    raise ValueError("TOKEN HAS BEEN NOT FOUND!!")

BASE_URL = f"https://api.telegram.org/bot{TOKEN}"

def get_updates(offset=None):
    """Fetches updates from Telegram using long polling."""
    try:
        response = requests.get(
            f"{BASE_URL}/getUpdates",
            params={
                "offset": offset,
                "timeout": 30
            },
            timeout=35
        )
        response.raise_for_status()  # FIXED: rise_for_status -> raise_for_status
        data = response.json()

        if not data.get("ok"):       # FIXED: "Ok" -> "ok"
            logger.error(f"Telegram API ERROR: {data}")
            return []

        return data.get("result", []) # FIXED: "resutl" -> "result"
    except requests.RequestException as e:
        logger.warning(f"Network error during getUpdates: {e}")
        return []

def send_message(chat_id, text, reply_to_message_id=None):
    """Sends a text message back to a specific chat ID."""
    payload = {
        "chat_id": chat_id,
        "text": text,
        "parse_mode": "Markdown"
    }
    if reply_to_message_id:
        payload["reply_to_message_id"] = reply_to_message_id

    try: 
        response = requests.post(
            f"{BASE_URL}/sendMessage",
            data=payload,
            timeout=10
        )
        response.raise_for_status()
        return response.json()
    except requests.RequestException as e:
        logger.error(f"Failed to send message to {chat_id}: {e}")  # FIXED: added missing 'f'
        return None

# =============================================================================
# FIXED: These functions are now OUTSIDE send_message (global scope)
# =============================================================================

def handle_start(chat_id, user_first_name):
    text = (
        f"In the first moment, go ti fuder {user_first_name}. Its a falta de educação what do you do now."
        "Falta de educação of the cacete inclusive. Vai falar assim com a sua vó, não comigo."
        "Tu pode digitar:\n\n/vitor - Pra xingar o vitor (manda um e-mail para ele xingando ele)\n/nfode - Pra não fuder."
    )
    send_message(chat_id, text)

def handle_help(chat_id):
    text = (
        "*Comandos disponíveis - V0.1*\n"
        "/start - Para iniciar a conversa\n"
        "/vitor - Para xingar o Vitor\n"
        "/nfode - Para não foder"
    )
    send_message(chat_id, text)

def route_message(message):
    """Parses incoming text and routes it based on intent/commands."""
    chat_id = message["chat"]["id"]
    text = message.get("text", "").strip()
    user = message.get("from", {})
    first_name = user.get("first_name", "Human")

    logger.info(f"Mensagem recebida de {first_name} ({chat_id}): {text}")  # FIXED: syntax error

    if text.startswith("/start"):
        handle_start(chat_id, first_name)
    elif text.startswith("/vitor"):  # FIXED: startwith -> startswith
        send_message(chat_id, "Vai se foder Vitor")
    elif text.startswith("/nfode"):
        send_message(chat_id, "Nada foi fodido.")
    else:
        send_message(chat_id, "Tá querendo muito é dar sua bunda rapais. Digita direito fela da puta")

def main():
    """Main application loop with offset persistence safety."""
    logger.info("Bot started successfully in raw polling mode...")
    last_update_id = None
    
    while True:
        try:
            updates = get_updates(
                offset=last_update_id + 1 if last_update_id is not None else None
            )

            for update in updates: 
                update_id = update["update_id"]  # FIXED: update[update_id] -> update["update_id"]

                # FIXED: Proper max tracking logic
                last_update_id = max(last_update_id, update_id) if last_update_id is not None else update_id

                message = update.get("message")
                if message and "text" in message:
                    route_message(message)

        except KeyboardInterrupt:
            logger.info("Bot Stopped manually by user.")
            break
        except Exception as e:
            logger.exception(f"Unexpected error in main loop: {e}")
            time.sleep(5)  # FIXED: sleeo -> sleep

if __name__ == "__main__":
    main()