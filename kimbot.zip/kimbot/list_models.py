import json
import os
import urllib.request

from dotenv import load_dotenv

load_dotenv()
key = os.getenv("GEMINI_API_KEY")

req = urllib.request.Request(
    "https://generativelanguage.googleapis.com/v1beta/models?pageSize=200",
    headers={"x-goog-api-key": key},
)
with urllib.request.urlopen(req, timeout=30) as resp:
    models = json.load(resp)["models"]

for m in models:
    if "generateContent" in m.get("supportedGenerationMethods", []):
        print(m["name"].removeprefix("models/"), "-", m.get("displayName", ""))