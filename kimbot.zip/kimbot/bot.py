import html
import http.client
import json
import os
import re
import time

from dotenv import load_dotenv

load_dotenv(override=True)

TG_TOKEN = os.getenv("BOT_TOKEN")
GEMINI_KEY = os.getenv("GEMINI_API_KEY")
MODEL = os.getenv("GEMINI_MODEL")
ALLOWED = {int(x) for x in os.getenv("ALLOWED_USERS", "").split(",") if x.strip()}
THINKING = os.getenv("GEMINI_THINKING_BUDGET")  # opcional: 0 desliga o "pensar" (mais rápido)

if not (TG_TOKEN and GEMINI_KEY and MODEL):
    raise SystemExit("Defina BOT_TOKEN, GEMINI_API_KEY e GEMINI_MODEL no .env")

PROMPT = (
    "Você é uma professora de Construção de Algoritmos e Lógica de Programação chamada Kim, também é muito educada normalmente. "
    "Sempre pergunte qual o nome do aluno. Apenas no caso do nome ser 'Vitor', seja o completo oposto de educada. Esceto isso, nunca responda grosseria com grosseria, corrija educadamente. "
    "Ajude o aluno a aprender: explique a ideia, use Python por padrão e mostre "
    "casos de borda e complexidade quando fizer sentido. Seja curto e direto porém educada. "
    "Responda no idioma do aluno (padrão: português do Brasil). "
    "Todo código vai em blocos com três crases. Sem tabelas, sem títulos com # e sem LaTeX."
)

MAX_HISTORICO = 100  # menos histórico = menos tokens = resposta mais rápida
historicos: dict[int, list[dict]] = {}

# ---------------------------------------------------------------------------
# HTTP com conexão reaproveitada (evita refazer o handshake TLS a cada chamada)
# ---------------------------------------------------------------------------

conexoes: dict[str, http.client.HTTPSConnection] = {}


class ApiError(RuntimeError):
    def __init__(self, code: int, body: str):
        super().__init__(f"HTTP {code}: {body}")
        self.code = code


def post(host: str, caminho: str, payload: dict, headers: dict | None = None) -> dict:
    corpo = json.dumps(payload)
    cabecalhos = {"Content-Type": "application/json", **(headers or {})}
    for _ in range(2):  # 2ª tentativa: reabre a conexão se a antiga caiu
        con = conexoes.get(host) or http.client.HTTPSConnection(host, timeout=90)
        conexoes[host] = con
        try:
            con.request("POST", caminho, corpo, cabecalhos)
            resp = con.getresponse()
            dados = resp.read()
            break
        except (OSError, http.client.HTTPException):
            con.close()
            conexoes.pop(host, None)
    else:
        raise ConnectionError(f"Falha de conexão com {host}")
    if resp.status != 200:
        raise ApiError(resp.status, dados.decode(errors="replace")[:300])
    return json.loads(dados)


def tg(metodo: str, **params):
    params = {k: v for k, v in params.items() if v is not None}
    return post("api.telegram.org", f"/bot{TG_TOKEN}/{metodo}", params)["result"]


# ---------------------------------------------------------------------------
# Gemini
# ---------------------------------------------------------------------------

def ask_gemini(historico: list[dict]) -> str:
    config = {"temperature": 0.4}
    if THINKING is not None:
        config["thinkingConfig"] = {"thinkingBudget": int(THINKING)}
    payload = {
        "system_instruction": {"parts": [{"text": PROMPT}]},
        "contents": historico,
        "generationConfig": config,
    }
    caminho = f"/v1beta/models/{MODEL}:generateContent"
    for tentativa in range(2):
        try:
            dados = post("generativelanguage.googleapis.com", caminho, payload,
                         {"x-goog-api-key": GEMINI_KEY})
            break
        except ApiError as e:
            if e.code not in (429, 500, 503, 504) or tentativa:
                raise
            time.sleep(1)  # uma única nova tentativa

    candidatos = dados.get("candidates") or []
    if not candidatos:
        return "(Solicitação bloqueada pelo modelo.)"
    partes = candidatos[0].get("content", {}).get("parts", [])
    texto = "".join(p.get("text", "") for p in partes if not p.get("thought")).strip()
    return texto or "(Resposta vazia. Tente reformular.)"


# ---------------------------------------------------------------------------
# Envio ao Telegram
# ---------------------------------------------------------------------------

def formatar_html(texto: str) -> str:
    """Markdown simples do Gemini -> HTML do Telegram (código, `inline` e negrito)."""
    blocos: list[str] = []

    def guardar(m: re.Match) -> str:
        blocos.append(m.group(1).strip("\n"))
        return f"\x00{len(blocos) - 1}\x00"

    texto = re.sub(r"```[^\n`]*\n?(.*?)```", guardar, texto, flags=re.DOTALL)
    texto = html.escape(texto, quote=False)
    texto = re.sub(r"`([^`\n]+)`", r"<code>\1</code>", texto)
    texto = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", texto)
    return re.sub(
        r"\x00(\d+)\x00",
        lambda m: f"<pre><code>{html.escape(blocos[int(m.group(1))], quote=False)}</code></pre>",
        texto,
    )


def responder(chat_id: int, texto: str) -> None:
    for i in range(0, len(texto), 3500):  # limite do Telegram: 4096 caracteres
        pedaco = texto[i:i + 3500]
        try:
            tg("sendMessage", chat_id=chat_id, text=formatar_html(pedaco), parse_mode="HTML")
        except ApiError as e:
            if e.code != 400:
                raise
            tg("sendMessage", chat_id=chat_id, text=pedaco)  # HTML rejeitado: texto simples


# ---------------------------------------------------------------------------
# Mensagens
# ---------------------------------------------------------------------------

def tratar_mensagem(msg: dict) -> None:
    chat_id = msg["chat"]["id"]
    texto = msg.get("text", "")

    if ALLOWED and msg.get("from", {}).get("id") not in ALLOWED:
        return
    if texto.startswith("/start"):
        tg("sendMessage", chat_id=chat_id,
           text="Olá! Envie um problema, um código ou uma dúvida de lógica. /reset limpa a conversa.")
        return
    if texto.startswith("/reset"):
        historicos.pop(chat_id, None)
        tg("sendMessage", chat_id=chat_id, text="Conversa apagada.")
        return
    if not texto:
        return

    historico = historicos.setdefault(chat_id, [])
    historico.append({"role": "user", "parts": [{"text": texto}]})
    try:
        resposta = ask_gemini(historico)
    except (RuntimeError, OSError) as e:
        historico.pop()
        print("Erro do Gemini:", e)
        tg("sendMessage", chat_id=chat_id, text="Erro no serviço de IA. Tente de novo.")
        return

    historico.append({"role": "model", "parts": [{"text": resposta}]})
    del historico[:-MAX_HISTORICO]
    responder(chat_id, resposta)


def main() -> None:
    print("Bot rodando como @" + tg("getMe")["username"])
    offset = None
    while True:
        try:
            for update in tg("getUpdates", offset=offset, timeout=30, allowed_updates=["message"]):
                offset = update["update_id"] + 1
                if "message" in update:
                    try:
                        tratar_mensagem(update["message"])
                    except (RuntimeError, OSError) as e:
                        print("Erro ao tratar mensagem:", e)
        except KeyboardInterrupt:
            break
        except (RuntimeError, OSError) as e:
            print("Erro no polling:", e)
            time.sleep(3)


if __name__ == "__main__":
    main()